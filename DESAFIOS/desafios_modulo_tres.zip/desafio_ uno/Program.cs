﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio__uno
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double dinero = 1000;


            for (int mes = 1; mes <= 12; mes++)
            {
                dinero = dinero * 1.02;
            }

            Console.WriteLine("El total acumulado en un año es: {0:N2}", dinero);

            Console.ReadKey();
        }
    }
}
