﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio_dos
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] facturacion = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120 };
            int[] trimestres = new int[4];

            for (int i = 0; i <= facturacion.Length - 1; i++)
            {
                if (i <= 2)
                {
                    trimestres[0] = trimestres[0] + facturacion[i];
                }
                else if (i > 2 && i <= 5)
                {
                    trimestres[1] = trimestres[1] + facturacion[i];
                }
                else if (i > 5 && i <= 8)
                {
                    trimestres[2] = trimestres[2] + facturacion[i];
                }
                else if (i > 8 && i <= 11)
                {
                    trimestres[3] = trimestres[3] + facturacion[i];
                }


            }

            Console.WriteLine($"Facturacion Primer Trimestre: {trimestres[0]}");
            Console.WriteLine($"Facturacion Segundo Trimestre: {trimestres[1]}");
            Console.WriteLine($"Facturacion Tercer Trimestre: {trimestres[2]}");
            Console.WriteLine($"Facturacion Cuarto Trimestre: {trimestres[3]}");

            Console.ReadKey();

        }
    }
}
