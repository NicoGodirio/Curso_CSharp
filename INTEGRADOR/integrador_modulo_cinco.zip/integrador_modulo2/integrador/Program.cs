﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace integrador
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string[] cursos = { "HTML", "POO", "SQL", "GIT", "REACT" };
            string[] cursos_elegidos = new string[cursos.Length];
            string carrera = " ";
            string rta = "n";

            int index = 0;

            Console.WriteLine("Ingrese nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese apellido: ");
            string apellido = Console.ReadLine();

            Console.WriteLine("Ingrese edad: ");
            int edad = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese mail: ");
            string mail = Console.ReadLine();
            Console.Clear();
            string strMensaje = string.Format("<<<<<<<<<<DATOS DEL ALUMNO>>>>>>>>>>>{0}NOMBRE:  {1}{0}APELLIDO: {2}{0}EDAD: {3}{0}MAIL:  {4}", Environment.NewLine, nombre, apellido, edad, mail);
            Console.WriteLine(strMensaje);


            Console.WriteLine("SON CORRECTOS LOS DATOS? ´s´ o ´n´: ");
            rta = Console.ReadLine();

            if (rta == "n")
            {
                Console.WriteLine("Datos incorrectos, presione una tecla para ejecutar nuevamente");
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Seleccione codigo de carrera\n 1.programacion .NET \n 2.programacion Java \n 3.programacion PHP");
                int codigo = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                switch (codigo)
                {
                    case 1:
                        carrera = "Programacion .NET";
                        break;

                    case 2:
                        carrera = "Programacion Java";
                        break;

                    case 3:
                        carrera = "Programacion PHP";
                        break;

                    default:
                        Console.WriteLine("Datos incorrectos, ejecutar nuevamente");
                        Console.ReadKey();
                        break;

                }
                
                Console.WriteLine("<<<CONSTANCIA DE INSCRIPCION>>>\nAlumno: " + nombre + " " + apellido + "\nCorreo electronico: " + mail + "\nCarrera: " + carrera);
                Console.WriteLine("Los datos informados son correctos? presione S o N");
                rta = Console.ReadLine();

                
                if (rta == "n")
                {
                    Console.WriteLine("Datos incorrectos, presione una tecla para ejecutar nuevamente");
                    Console.ReadKey();
                }
                else
                {
                    

                    Console.WriteLine("<<<<CURSOS DISPONIBLES>>>>");

                    for (int i = 0; i <= cursos.Length -1; i++)
                    {
                        Console.WriteLine($"{i + 1}. {cursos[i]}");
                    }

                    do
                    {

                        Console.WriteLine("Seleccione Codigo de Curso: ");
                        int codCurso = Convert.ToInt32(Console.ReadLine());
                        string variable = cursos[codCurso - 1];
                        cursos_elegidos[index] = variable;

                        index++;
                        if(index <= 4) 
                        {
                            Console.WriteLine("Quiere cargar otro curso?");
                            rta = Console.ReadLine();
                        }
                        
                        
                        

                    }while(index <= 4 && rta == "s");


                    Console.WriteLine("<<<CONSTANCIA DE INSCRIPCION>>>\nAlumno: " + nombre + " " + apellido + "\nCorreo electronico: " + mail + "\nCarrera: " + carrera + "\nCursos Elegidos:\n");
                    for (int j = 0; j <= index - 1; j++)
                    {
                        Console.WriteLine($"{j + 1}. {cursos_elegidos[j]}\n");
                        
                    }

                    Console.WriteLine("Presione una tecla para salir.");
                    Console.ReadKey();


                }



            }
        }
    }
}