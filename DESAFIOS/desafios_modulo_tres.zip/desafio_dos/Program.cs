﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio_dos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double dinero = 1000;

            for (int mes = 1; mes <= 12; mes++)
            {
                dinero = dinero * 1.03;

                if (dinero >= 1200)
                {
                    Console.WriteLine("Dinero total: {0:N2} en {1} meses", dinero, mes);
                    Console.ReadKey();
                }
            }
        }
    }
}
