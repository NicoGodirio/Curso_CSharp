﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio_uno
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] unvector = { 1002, 104, 309, 500 };
            int[] segVector = new int[unvector.Length];


            //int i = 0;
            //int j = unvector.Length - 1;

            //for (i = 0; i <= unvector.Length - 1; i++)
            //{
            //    segVector[i] = unvector[j];
            //    Console.WriteLine($"Primer vector: {unvector[i]}");
            //    Console.WriteLine($"Segundo vector: {segVector[i]}");
            //    j--;
            //}

            for (int i = unvector.Length - 1; i >= 0; i--)
            {
                segVector[i] = unvector[unvector.Length - i - 1];
                Console.WriteLine($"Primer vector: {unvector[i]}");
                Console.WriteLine($"Segundo vector: {segVector[i]}");
            }


            Console.ReadKey();

        }
    }
}
