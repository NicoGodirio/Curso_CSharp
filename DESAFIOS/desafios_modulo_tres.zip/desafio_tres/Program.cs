﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio_tres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int chances = 3;
            const string contGuardada = "asd";


            do
            {
                Console.WriteLine("Ingrese contraseña: ");
                string contrasena = Console.ReadLine();

                chances--;
                if (contrasena == contGuardada)
                {
                    Console.WriteLine("Bienvenido!!");
                    Console.ReadKey();
                    break;
                }
                else if (chances == 1)
                {
                    Console.WriteLine("Atencion!! Ultima oportunidad!");

                }
                else
                {
                    if(chances == 0)
                    {
                        Console.WriteLine("Tres veces fallidas!!");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Contraseña erronea, tiene {0} chances", chances);
                        Console.ReadKey();
                    }
                    

                }


            } while (chances > 0);


        }
    }
}
